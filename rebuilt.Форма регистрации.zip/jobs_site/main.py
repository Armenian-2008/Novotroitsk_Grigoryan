from flask import Flask, render_template, request, redirect
import datetime
import sqlalchemy
from sqlalchemy import orm
from data import db_session
from data.jobs import Jobs
from data.users import User


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route("/")
def index():
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs)
    return render_template("index.html", jobs=jobs)


@app.route("/register", methods=['POST', 'GET'])
def register():
    if request.method == "POST":
        email = request.form['email']
        password = request.form['hashed_password']
        r_password = request.form['r-password']
        surname = request.form['surname']
        name = request.form['name']
        age = request.form['age']
        position = request.form['position']
        speciality = request.form['speciality']
        address = request.form['address']

        if r_password == password:
            user = User(email=email, hashed_password=password, surname=surname, name=name, age=age, position=position,
                        speciality=speciality, address=address)
            try:
                db_sess = db_session.create_session()
                db_sess.add(user)
                db_sess.commit()
                return redirect('/')
            except:
                return "При добавлении пользователя произошла ошибка"
        else:
            return "Пароли не совподают"
    else:
        return render_template("register.html")


if __name__ == '__main__':
    db_session.global_init("db/blogs.db")
    app.run()