from flask import Flask, render_template
import json


f = {
    "news": [
        {
            "title": "Миссия Колонизация Марса",
            "content": "И на Марсе будут яблони цвести!"
        }
    ]
}

with open("base.json", mode="w", encoding="utf8") as file:
    json.dump(f, file)

app = Flask(__name__)

@app.route('/list_prof/ol')
def index():
    with open("base.json", "rt", encoding="utf8") as f:
        base_list = json.loads(f.read())
    print(base_list)
    return render_template('new.html', news=base_list)

@app.route('/list_prof/ul')
def index2():
    with open("base.json", "rt", encoding="utf8") as f:
        base_list = json.loads(f.read())
    print(base_list)
    return render_template('new2.html', news=base_list)


if __name__ == '__main__':
    app.run()